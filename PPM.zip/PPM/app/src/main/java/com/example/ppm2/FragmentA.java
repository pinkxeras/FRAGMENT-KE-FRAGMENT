package com.example.ppm2;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link FragmentA#newInstance} factory method to
 * create an instance of this fragment.
 */
public class FragmentA extends Fragment {
    private SharedViewModel sharedViewModel;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_a, container, false);
        sharedViewModel = new ViewModelProvider(requireActivity()).get(SharedViewModel.class);

        Button btnTGS = view.findViewById(R.id.btnTGS);
        btnTGS.setOnClickListener(v -> {
            sharedViewModel.selectItem(" RATING 4.8 "+"\n"+"Tahun 2017"+"\n"+"Sutradara Michael Gracey"+"\n"+"Sinopsis:Film ini menceritakan kisah tentang PT Barnum (Hugh Jackman) yang diberhentikan dari perusahaannya yang akan bangkrut. Barnum pun berpikir meminjam uang dari bank untuk membeli sebuah museum dimana museum tersebut memajang berbagai macam patung lilin.\n" +
                    "\n" +
                    "\n" +
                    "Sayangnya penjualan tiket museum sangat rendah. Di tengah sepi pengunjung museum, sang anak pun memberikan ide untuk mempertunjukkan sesuatu yang hidup untuk museumnya. Saat itulah ia mulai bertemu dengan banyak pemain untuk bisa bergabung dalam pertunjukkan sirkusnya.");
        });

        Button btnBC = view.findViewById(R.id.btnBC);
        btnBC.setOnClickListener(v -> {
            sharedViewModel.selectItem("Rating 4.8"+"\n"+"Tahun 2015"+"\n"+"Sutradara Tatsuya Yoshihara"+"\n"+"Sinopsis : Black Clover adalah serial manga dan anime bergenre fantasi yang bercerita tentang Asta dan Yuno, dua anak laki-laki yang berjuang untuk menjadi Raja Penyihir di dunia sihir");
        });

        Button btnAVATAR = view.findViewById(R.id.btnAVATAR);
        btnAVATAR.setOnClickListener(v -> {
            sharedViewModel.selectItem("Rating 4.3"+"\n"+"Tahun 2022"+"\n"+"Sutradara Cameron"+"\n"+"Sinopsis : Avatar 2 menceritakan perjalanan keluarga lima anak Jake Sully dan Neytiri yang baru ditemukan. Terlepas dari upaya terbaik mereka untuk menjaga keluarga mereka tetap bersama. \n" +
                    "\n" +
                    "Akan tetapi, ancaman yang akrab muncul kembali dan memaksa Jake, Neytiri, dan anak-anak mereka untuk melarikan diri ke tanah klan Metkayina di lautan Pandora. ");
        });

        return view;
    }
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public FragmentA() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment FragmentA.
     */
    // TODO: Rename and change types and number of parameters
    public static FragmentA newInstance(String param1, String param2) {
        FragmentA fragment = new FragmentA();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }


}