package com.example.ppm2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FragmentA fragmentA = new FragmentA();
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragment_container_a, fragmentA)
                .commit();

        FragmentB fragmentB = new FragmentB();
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragment_container_b, fragmentB)
                .commit();
    }
}